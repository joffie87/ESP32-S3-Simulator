/*
@TVN_META
role: config_root
desc: Vite build configuration for React + Pyodide optimization
@END_META
*/

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/ESP32-S3-Simulator/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
  },
  optimizeDeps: {
    exclude: ['pyodide']
  }
})
